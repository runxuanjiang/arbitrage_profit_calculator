from roots import *
import hashlib
import sys
message = sys.argv[1]

# Your code to forge a signature goes here.

print integer_to_base64(forged_signature)
