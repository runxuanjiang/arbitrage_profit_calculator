
Blue!"""
from hashlib import sha256
print sha256(blob).hexdigest()