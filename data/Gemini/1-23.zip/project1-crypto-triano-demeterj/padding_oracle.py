import httplib, urlparse, urllib, sys
import base64, copy

def valid_padding(sender, recipient, query):
    url = "https://eecs388.org/paddingoracle/verify?message=" + query + "&from=" + sender + "&to=" + recipient
    parsedUrl = urlparse.urlparse(url)

    try:
        conn = httplib.HTTPSConnection(parsedUrl.hostname,parsedUrl.port)
        conn.request("GET", parsedUrl.path + "?" + parsedUrl.query)
        message = conn.getresponse().read()
    except KeyboardInterrupt:
        raise
    except:
        print "error"

    if message == "Error 400: Invalid Padding":
        # This is a padding error
        return False
    elif message == "Invalid Validation" or message == "Valid Validation":
        # Correct padding!
        return True
    else:
        print "Bad response:\n" + message
        exit()

def main():
    if len(sys.argv) != 4:
        print("Usage: python padding_oracle.py \"from\" \"to\" \"base16_ciphertext\"")
        exit()

    # Add code here

if __name__ == "__main__":
    main()
